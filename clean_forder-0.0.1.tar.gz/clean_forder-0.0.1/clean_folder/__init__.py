from my_repository.First_repo.clean_folder.clean_folder.clean import main

__all__ = ['main']